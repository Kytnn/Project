package com.example.thamkhao.Model;

public class ChiTietBanLe {
    String soHD,maThuoc,soLuong;

    public String getSoHD() {
        return soHD;
    }

    public void setSoHD(String soHD) {
        this.soHD = soHD;
    }

    public String getMaThuoc() {
        return maThuoc;
    }

    public void setMaThuoc(String maThuoc) {
        this.maThuoc = maThuoc;
    }

    public String getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(String soLuong) {
        this.soLuong = soLuong;
    }

    @Override
    public String toString() {
        return "ChiTietBanLe{" +
                "soHD='" + soHD + '\'' +
                ", maThuoc='" + maThuoc + '\'' +
                ", soLuong='" + soLuong + '\'' +
                '}';
    }
}
