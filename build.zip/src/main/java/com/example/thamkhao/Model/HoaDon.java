package com.example.thamkhao.Model;

public class HoaDon {
    String soHD,ngayHD,maNT;

    public String getSoHD() {
        return soHD;
    }

    public void setSoHD(String soHD) {
        this.soHD = soHD;
    }

    public String getNgayHD() {
        return ngayHD;
    }

    public void setNgayHD(String ngayHD) {
        this.ngayHD = ngayHD;
    }

    public String getMaNT() {
        return maNT;
    }

    public void setMaNT(String maNT) {
        this.maNT = maNT;
    }

    @Override
    public String toString() {
        return "HoaDon{" +
                "soHD='" + soHD + '\'' +
                ", ngayHD='" + ngayHD + '\'' +
                ", maNT='" + maNT + '\'' +
                '}';
    }
}
