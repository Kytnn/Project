package com.example.thamkhao.Model;

public class NhaThuoc {
    String maNT,tenNT,diaChi;

    public String getMaNT() {
        return maNT;
    }

    public void setMaNT(String maNT) {
        this.maNT = maNT;
    }

    public String getTenNT() {
        return tenNT;
    }

    public void setTenNT(String tenNT) {
        this.tenNT = tenNT;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    @Override
    public String toString() {
        return "NhaThuoc{" +
                "maNT='" + maNT + '\'' +
                ", tenNT='" + tenNT + '\'' +
                ", diaChi='" + diaChi + '\'' +
                '}';
    }
}
