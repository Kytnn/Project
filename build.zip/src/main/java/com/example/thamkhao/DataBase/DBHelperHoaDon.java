package com.example.thamkhao.DataBase;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelperHoaDon extends SQLiteOpenHelper {
    public DBHelperHoaDon( Context context) {
        super(context, "QLHoaDon", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql="create table HoaDon(mahd text ,ngaynhap text, mant text )";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
