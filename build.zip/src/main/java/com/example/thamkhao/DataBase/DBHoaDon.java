package com.example.thamkhao.DataBase;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.thamkhao.Model.HoaDon;
import java.util.ArrayList;

public class DBHoaDon {
    DBHelperHoaDon dbHoaDon;

    public DBHoaDon(Context context) {
        dbHoaDon= new DBHelperHoaDon(context);
    }

    public void Them(HoaDon hoaDon)
    {
        SQLiteDatabase db = dbHoaDon.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("sohd",hoaDon.getSoHD());
        values.put("ngayhd",hoaDon.getNgayHD());
        values.put("mant",hoaDon.getMaNT());
        db.insert("HoaDon",null,values);
    }

    public void Sua(HoaDon hoaDon)
    {

        SQLiteDatabase db = dbHoaDon.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("mahd",hoaDon.getSoHD());
        values.put("ngaynhap",hoaDon.getNgayHD());
        values.put("mant",hoaDon.getMaNT());
        db.update("HoaDon",values,"mahd ='"+hoaDon.getSoHD() +"'",null);
    }


    public void Xoa(HoaDon hoaDon)
    {

        SQLiteDatabase db = dbHoaDon.getWritableDatabase();
        String sql ="Delete from HoaDon where mahd= '"+hoaDon.getSoHD()+"'";
        db.execSQL(sql);

    }

    public ArrayList<HoaDon> LayDL()
    {
        ArrayList<HoaDon> data = new ArrayList<>();
        String sql="select * from HoaDon";
        SQLiteDatabase db= dbHoaDon.getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);

        try {
            cursor.moveToFirst();
            do {
                HoaDon hoaDon = new HoaDon();
                hoaDon.setSoHD(cursor.getString(0));
                hoaDon.setNgayHD(cursor.getString(1));
                hoaDon.setMaNT(cursor.getString(2));
                data.add(hoaDon);
            }
            while (cursor.moveToNext());
        }
        catch (Exception ex)
        {
        }
        return  data;
    }
}
