package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.example.thamkhao.Adapter.ChiTietBanLeAdapter;
import com.example.thamkhao.Model.ChiTietBanLe;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class FormChiTietBanLe extends AppCompatActivity {
    ListView lvChiTiet;

    ArrayList<ChiTietBanLe> data_BTV = new ArrayList<>();
    ChiTietBanLeAdapter adapter_BTV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_chi_tiet_ban_le);
        setControl();
        setEvent();
    }

    private void setEvent() {
        khoitao();
        adapter_BTV = new ChiTietBanLeAdapter(this, R.layout.list_chitietbanle, data_BTV);
        lvChiTiet.setAdapter((ListAdapter) adapter_BTV);

    }

    private void khoitao() {
        ChiTietBanLe chiTietBanLe = new ChiTietBanLe();
        chiTietBanLe.setSoHD("HD01");
        chiTietBanLe.setMaThuoc("A02");
        chiTietBanLe.setSoLuong("140");
        data_BTV.add(chiTietBanLe);
    }

    private void setControl() {
        lvChiTiet = findViewById(R.id.lvChiTiet);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item:
                Intent intent0 = new Intent(FormChiTietBanLe.this,MainActivity.class);
                startActivity(intent0);
                return true;
            case R.id.item1:
                Intent intent = new Intent(FormChiTietBanLe.this,FormHoaDon.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                Intent intent1 = new Intent(FormChiTietBanLe.this,FormNhaThuoc.class);
                startActivity(intent1);
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(FormChiTietBanLe.this,FormThuoc.class);
                startActivity(intent2);
                return true;
            case R.id.item4:
                Intent intent3 = new Intent(FormChiTietBanLe.this,FormChiTietBanLe.class);
                startActivity(intent3);
                return true;
            case R.id.item5:
                AlertDialog.Builder builder = new AlertDialog.Builder(FormChiTietBanLe.this);
                builder.setTitle("Thông Báo !!!");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Bạn Muốn Thoát ?");
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

}