package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.example.thamkhao.R;

public class QuanLyUngDung extends AppCompatActivity {
    Button btnDS,btnThuoc,btnNhaThuoc,btnHoaDon,btnCTBL;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quan_ly_ung_dung);
        setControl();
        setEvent();
    }

    private void setEvent() {
        btnDS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLyUngDung.this, ListContact.class);
                startActivity(intent);
            }
        });

        btnHoaDon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLyUngDung.this, FormHoaDon.class);
                startActivity(intent);
            }
        });

        btnNhaThuoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLyUngDung.this, FormNhaThuoc.class);
                startActivity(intent);
            }
        });

        btnThuoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLyUngDung.this, FormThuoc.class);
                startActivity(intent);
            }
        });

        btnCTBL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(QuanLyUngDung.this, FormChiTietBanLe.class);
                startActivity(intent);
            }
        });
    }

    private void setControl() {
        btnDS = findViewById(R.id.dsContact);
        btnThuoc = findViewById(R.id.btnThuoc);
        btnNhaThuoc = findViewById(R.id.btnNhaThuoc);
        btnHoaDon = findViewById(R.id.btnHoaDon);
        btnCTBL = findViewById(R.id.btnChiTietBanLe);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}


