package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;

import com.example.thamkhao.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    AnimationDrawable timAnimation,tim1Animation;
    ImageView tim1,tim2;
    Button btnThoat,btnThongTin,btnQLUD;
    Spinner spThongTin;
    ListView lvShow;
    ArrayList<String> data_CT = new ArrayList<>();
    ArrayAdapter adapter_CT;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setControl();
        setEvent();
    }

    private void setEvent() {
        tim1.setBackgroundResource(R.drawable.animation);
        tim2.setBackgroundResource(R.drawable.animation);
        timAnimation = (AnimationDrawable) tim1.getBackground();
        tim1Animation = (AnimationDrawable) tim2.getBackground();

        khoitao();
        adapter_CT = new ArrayAdapter(this, android.R.layout.simple_spinner_item,
                data_CT);
        spThongTin.setAdapter(adapter_CT);

        btnThoat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Thông Báo !!!");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Bạn Muốn Thoát ?");
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        btnThongTin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MapLocation.class);
                startActivity(intent);
            }
        });

        btnQLUD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, QuanLyUngDung.class);
                startActivity(intent);
            }
        });



    }

    private void khoitao() {
        data_CT.add("Hóa đơn");
        data_CT.add("Nhà thuốc");
        data_CT.add("Thuốc");
        data_CT.add("Chi tiết bán lẽ");
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        timAnimation.start();
        tim1Animation.start();
    }

    private void setControl() {
        tim1 = (ImageView) findViewById(R.id.imageaa);
        tim2 = (ImageView) findViewById(R.id.imagea);
        btnThoat = findViewById(R.id.btnThoat);
        btnThongTin = findViewById(R.id.btn_thongtin);
        btnQLUD = findViewById(R.id.QLUD);
        spThongTin = findViewById(R.id.spinner);
        lvShow = findViewById(R.id.lvShow);
    }

    //Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item:
                Intent intent0 = new Intent(MainActivity.this,MainActivity.class);
                startActivity(intent0);
                return true;
            case R.id.item1:
                Intent intent = new Intent(MainActivity.this,FormHoaDon.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                Intent intent1 = new Intent(MainActivity.this,FormNhaThuoc.class);
                startActivity(intent1);
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(MainActivity.this,FormThuoc.class);
                startActivity(intent2);
                return true;
            case R.id.item4:
                Intent intent3 = new Intent(MainActivity.this,FormChiTietBanLe.class);
                startActivity(intent3);
                return true;
            case R.id.item5:
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Thông Báo !!!");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Bạn Muốn Thoát ?");
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}