package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.thamkhao.Adapter.HoaDonAdapter;
import com.example.thamkhao.DataBase.DBHoaDon;
import com.example.thamkhao.Model.HoaDon;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class FormHoaDon extends AppCompatActivity {
    Button btnThem, btnXoa, btnSua, btnClear;
    EditText txtSoHD, txtNgayHD, txtMaNT;
    ListView lvHoaDon;

    ArrayList<HoaDon> data_BTV = new ArrayList<>();
    HoaDonAdapter adapter_BTV;
    int index=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_hoa_don);
        setControl();
        setEvent();
    }



    private void setEvent() {

        khoiTao();
        adapter_BTV = new HoaDonAdapter(this, R.layout.list_hoadon, data_BTV);
        lvHoaDon.setAdapter(adapter_BTV);

        lvHoaDon.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                HoaDon hoaDon = data_BTV.get(position);
                txtSoHD.setText(hoaDon.getSoHD());
                txtNgayHD.setText(hoaDon.getNgayHD());
                txtMaNT.setText(hoaDon.getMaNT());
                index= position;
            }
        });

    }

    private void khoiTao() {
        HoaDon hoaDon = new HoaDon();
        hoaDon.setSoHD("HD01");
        hoaDon.setNgayHD("22/05/2020");
        hoaDon.setMaNT("NT01");
        data_BTV.add(hoaDon);

    }

    private void setControl() {
        txtSoHD = findViewById(R.id.tvSoHD);
        txtNgayHD = findViewById(R.id.tvNgayHD);
        txtMaNT = findViewById(R.id.tvMaNT);
        btnThem = findViewById(R.id.btnThem);
        btnXoa = findViewById(R.id.btnXoa);
        btnSua = findViewById(R.id.btnSua);
        btnClear = findViewById(R.id.btnClear);
        lvHoaDon = findViewById(R.id.lvHoaDon);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item:
                Intent intent0 = new Intent(FormHoaDon.this,MainActivity.class);
                startActivity(intent0);
                return true;
            case R.id.item1:
                Intent intent = new Intent(FormHoaDon.this,FormHoaDon.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                Intent intent1 = new Intent(FormHoaDon.this,FormNhaThuoc.class);
                startActivity(intent1);
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(FormHoaDon.this,FormThuoc.class);
                startActivity(intent2);
                return true;
            case R.id.item4:
                Intent intent3 = new Intent(FormHoaDon.this,FormChiTietBanLe.class);
                startActivity(intent3);
                return true;
            case R.id.item5:
                AlertDialog.Builder builder = new AlertDialog.Builder(FormHoaDon.this);
                builder.setTitle("Thông Báo !!!");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Bạn Muốn Thoát ?");
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }


}