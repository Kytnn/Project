package com.example.thamkhao.GiaoDien;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.EditText;

import com.example.thamkhao.DataBase.DBHoaDon;
import com.example.thamkhao.Model.HoaDon;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class ChiTietHD extends AppCompatActivity {
    EditText txtSoHD, txtNgayHD, txtMaNT;
    ArrayList<HoaDon> data_SV = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_h_d);
        setConTrol();
        setEvent();
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);
    }

    private void setEvent() {
        String ma= getIntent().getExtras().getString("ma");
        DBHoaDon dbHoaDon = new DBHoaDon(this);
        data_SV = dbHoaDon.LayDL();
        txtSoHD.setText(data_SV.get(0).getSoHD());
        txtNgayHD.setText(data_SV.get(0).getNgayHD());
        txtMaNT.setText(data_SV.get(0).getMaNT());

    }



    private void setConTrol() {
        txtSoHD = findViewById(R.id.txtHD);
        txtNgayHD = findViewById(R.id.txtNgayHD);
        txtMaNT = findViewById(R.id.txtMaNT);


    }
}