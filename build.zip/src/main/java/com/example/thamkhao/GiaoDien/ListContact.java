package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.thamkhao.Adapter.CustomAdapter;
import com.example.thamkhao.Model.Contact;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class ListContact extends AppCompatActivity {
    private CustomAdapter customAdapter;
    private ListView lvContact;
    private ArrayList<Contact> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_contact);
        setControl();
        setEvent();
    }

    private void setEvent() {
        setData();
        customAdapter = new CustomAdapter(this, R.layout.contact_item, arrayList);
        lvContact.setAdapter(customAdapter);

        lvContact.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                String number = arrayList.get(position).getNumber().replaceAll("-","");
                Log.e("TAG",number);
                callIntent.setData(Uri.parse("tel:" + number));
                startActivity(callIntent);
            }
        });

    }

    private void setData() {
        Cursor phones = getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
        while (phones.moveToNext()) {
            Contact contact = new Contact();
            contact.setName(phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)));
            contact.setNumber(phones.getString(phones.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)));
            arrayList.add(contact);
            Log.e("TAG", contact.getName());
        }
        phones.close();
    }

    private void setControl() {
        lvContact = findViewById(R.id.lv_contact);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}