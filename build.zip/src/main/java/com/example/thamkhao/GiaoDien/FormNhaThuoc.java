package com.example.thamkhao.GiaoDien;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.thamkhao.Adapter.HoaDonAdapter;
import com.example.thamkhao.Adapter.NhaThuocAdapter;
import com.example.thamkhao.Model.HoaDon;
import com.example.thamkhao.Model.NhaThuoc;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class FormNhaThuoc extends AppCompatActivity {
    Button btnThem, btnXoa, btnSua, btnClear;
    EditText txtSoHD, txtNgayHD, txtMaNT;
    ListView lvHoaDon;

    ArrayList<NhaThuoc> data_BTV = new ArrayList<>();
    NhaThuocAdapter adapter_BTV;
    int index=-1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_nha_thuoc);
        setControl();
        setEvent();
    }

    private void setEvent() {

        khoiTao();
        adapter_BTV = new NhaThuocAdapter(this, R.layout.list_nhathuoc, data_BTV);
        lvHoaDon.setAdapter(adapter_BTV);

        btnThem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NhaThuoc nhaThuoc = new NhaThuoc();
                nhaThuoc.setMaNT(txtSoHD.getText().toString());
                nhaThuoc.setTenNT(txtNgayHD.getText().toString());
                nhaThuoc.setDiaChi(txtMaNT.getText().toString());
                data_BTV.add(nhaThuoc);
                adapter_BTV.notifyDataSetChanged();
            }
        });

        btnXoa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                data_BTV.remove(index);
                adapter_BTV.notifyDataSetChanged();
            }
        });

        btnSua.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NhaThuoc nhaThuoc =data_BTV.get(index);
                nhaThuoc.setMaNT(txtSoHD.getText().toString());
                nhaThuoc.setTenNT(txtNgayHD.getText().toString());
                nhaThuoc.setDiaChi(txtMaNT.getText().toString());
                adapter_BTV.notifyDataSetChanged();
            }
        });
        btnClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtSoHD.setText("");
                txtNgayHD.setText("");
                txtMaNT.setText("");
            }
        });

        lvHoaDon.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                NhaThuoc nhaThuoc = data_BTV.get(position);
                txtSoHD.setText(nhaThuoc.getMaNT());
                txtNgayHD.setText(nhaThuoc.getTenNT());
                txtMaNT.setText(nhaThuoc.getDiaChi());
                index= position;
            }
        });

    }

    private void khoiTao() {
        NhaThuoc nhaThuoc = new NhaThuoc();
        nhaThuoc.setMaNT("NT01");
        nhaThuoc.setTenNT("Anh Thư");
        nhaThuoc.setDiaChi("Gò vấp");
        data_BTV.add(nhaThuoc);

    }

    private void setControl() {
        txtSoHD = findViewById(R.id.txtMaNhaThuoc);
        txtNgayHD = findViewById(R.id.txtTenNhaThuoc);
        txtMaNT = findViewById(R.id.txtDiaChiNT);
        btnThem = findViewById(R.id.btnThem);
        btnXoa = findViewById(R.id.btnXoa);
        btnSua = findViewById(R.id.btnSua);
        btnClear = findViewById(R.id.btnClear);
        lvHoaDon = findViewById(R.id.lvNhaThuoc);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.item:
                Intent intent0 = new Intent(FormNhaThuoc.this,MainActivity.class);
                startActivity(intent0);
                return true;
            case R.id.item1:
                Intent intent = new Intent(FormNhaThuoc.this,FormHoaDon.class);
                startActivity(intent);
                return true;
            case R.id.item2:
                Intent intent1 = new Intent(FormNhaThuoc.this,FormNhaThuoc.class);
                startActivity(intent1);
                return true;
            case R.id.item3:
                Intent intent2 = new Intent(FormNhaThuoc.this,FormThuoc.class);
                startActivity(intent2);
                return true;
            case R.id.item4:
                Intent intent3 = new Intent(FormNhaThuoc.this,FormChiTietBanLe.class);
                startActivity(intent3);
                return true;
            case R.id.item5:
                AlertDialog.Builder builder = new AlertDialog.Builder(FormNhaThuoc.this);
                builder.setTitle("Thông Báo !!!");
                builder.setIcon(R.mipmap.ic_launcher);
                builder.setMessage("Bạn Muốn Thoát ?");
                builder.setNegativeButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder.setPositiveButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });
                AlertDialog dialog = builder.create();
                dialog.show();
                return true;
            case R.id.itemback:
                onBackPressed();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}