package com.example.thamkhao.GiaoDien;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.thamkhao.R;

public class FormQuanLyApp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_quan_ly_app);
    }
}