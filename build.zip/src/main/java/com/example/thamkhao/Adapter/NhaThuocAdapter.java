package com.example.thamkhao.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.thamkhao.Model.HoaDon;
import com.example.thamkhao.Model.NhaThuoc;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class NhaThuocAdapter extends ArrayAdapter {
    Context context;
    int resource;
    ArrayList<NhaThuoc> data;

    public NhaThuocAdapter(Context context, int resource, ArrayList<NhaThuoc> data) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.data = data;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view= LayoutInflater.from(context).inflate(resource,null);

        ImageView imgHoaDon= view.findViewById(R.id.imgHinh);
        ImageView imgChiTiet= view.findViewById(R.id.imgDetail);

        TextView tvSoHD= view.findViewById(R.id.tvHoaDon);
        TextView ngayHD= view.findViewById(R.id.tvNgayNhap);
        TextView tvMaNT= view.findViewById(R.id.tvMaNhaThuoc);

        NhaThuoc nhaThuoc = data.get(position);

        imgHoaDon.setImageResource(R.drawable.nhathuoc);
        imgChiTiet.setImageResource(R.drawable.ic_ct);
        tvSoHD.setText(nhaThuoc.getMaNT());
        ngayHD.setText(nhaThuoc.getTenNT());
        tvMaNT.setText(nhaThuoc.getDiaChi());
        return  view;

    }
}
