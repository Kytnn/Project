package com.example.thamkhao.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.thamkhao.Model.Contact;
import com.example.thamkhao.R;

import java.util.ArrayList;

public class CustomAdapter extends ArrayAdapter {
    private ArrayList<Contact> arrayList = new ArrayList<>();
    private int resource;
    private Context context;

    public CustomAdapter(Context context, int resource, ArrayList<Contact> arrayList) {
        super(context, resource);
        this.context = context;
        this.resource = resource;
        this.arrayList = arrayList;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = LayoutInflater.from(context).inflate(R.layout.contact_item, null);

        TextView tvName = convertView.findViewById(R.id.tv_name);
        TextView tvNumber = convertView.findViewById(R.id.tv_number);

        tvName.setText(arrayList.get(position).getName());
        tvNumber.setText(arrayList.get(position).getNumber());

        return convertView;
    }

}
